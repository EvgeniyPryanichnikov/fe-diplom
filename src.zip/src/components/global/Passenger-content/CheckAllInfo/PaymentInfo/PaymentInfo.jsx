import React from 'react'
import s from './PaymentInfo.module.scss'

const PaymentInfo = () => {
  return (
    <div>PaymentInfo</div>
  )
}

export default PaymentInfo